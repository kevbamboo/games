// --== CS400 File Header Information ==--
// Name: Kevin Yiyang Song
// Email: kysong@wisc.edu
// Notes to Grader: Did not include definitions of params/methods that were very self-explanatory


/**
 * @author Kevin
 * 
 * Models a man being hanged
 */
public class HangedMan {

  private int livesLeft;
  private boolean isDead;

  public HangedMan(int lives) {
    livesLeft = lives;
    isDead = false;
  }

  public void loseLife() {
    livesLeft--;
    if (livesLeft == 0) {
      isDead = true;
    }
  }

  public int getLives() {
     return livesLeft;
  }
  
  /**
   * Show hangman picture
   */
  public void hang() {
    System.out.println("\n--------");
    System.out.println("       |");
    System.out.println("       |");

    if (livesLeft <= 5) {
      System.out.println("      ---");
      System.out.println("      | |");
      System.out.println("      ---");
    }
    if (livesLeft == 4) {
      System.out.println("       |");
      System.out.println("       |");
      System.out.println("       |");
    }
    else if (livesLeft == 3) {
      System.out.println("       |");
      System.out.println("    ---|");
      System.out.println("       |");
    }
    else if (livesLeft <= 2) {
      System.out.println("       |");
      System.out.println("    ---|---");
      System.out.println("       |");
    }
    if (livesLeft == 1) {
      System.out.println("      /");
      System.out.println("     /");
    }
    else if (livesLeft == 0) {
      System.out.println("      / \\");
      System.out.println("     /   \\");
    }
    
    System.out.println();
  }

  public boolean isDead() {
    return isDead;
  }
}
