// --== CS400 File Header Information ==--
// Name: Kevin Yiyang Song
// Email: kysong@wisc.edu
// Notes to Grader: Did not add comments to things that were self-explanatory (which here, is really everythin)


public class HangmanPhrase {
  private String phrase;
  private String difficulty;
  
  public HangmanPhrase(String phrase, String difficulty) {
    this.phrase = phrase;
    this.difficulty = difficulty;
  }

  public String getPhrase() {
    return this.phrase;
  }

  public String getDifficulty() {
    return this.difficulty;
  }

  public String toString() {
    return "[" + this.phrase + " -> " + this.difficulty + "]";
  }
}
