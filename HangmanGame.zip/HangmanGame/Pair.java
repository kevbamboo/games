// --== CS400 File Header Information ==--
// Name: Kevin Yiyang Song
// Email: kysong@wisc.edu
// Notes to Grader: Did not include definitions of params/methods that were very self-explanatory

/**
 * This class models a key-value pair used in the HashTableMap class
 * @author Kevin
 *
 * @param <KeyType> - type of the key
 * @param <ValueType> - type of the value
 */
public class Pair <KeyType, ValueType> {
  private KeyType key;
  private ValueType value;
  
  /**
   * Create a new key-value Pair
   * @param key
   * @param value
   */
  public Pair(KeyType key, ValueType value) {
    this.key = key;
    this.value = value;
  }
  
  public KeyType getKey() {
    return this.key;
  }
  
  public ValueType getValue() {
    return this.value;
  }
  
  /**
   * Returns the toString version of this Pair
   */
  public String toString() {
    return key + " - " + value;
  }
}
