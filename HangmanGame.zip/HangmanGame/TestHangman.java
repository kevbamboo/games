// --== CS400 File Reader Information ==--
// Name: Kevin Yiyang Song
// Email: kysong@wisc.edu
// Notes to Grader: What each method is testing is in the mtehod name, so I didn't write method header comments

import java.io.File;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.ArrayList;

/**
 * @author Kevin
 * 
 * Tests the methods of HangmanGame, HangedMan and HashTableMap
 */
public class TestHangman {
  @Test
  public void testHashTableMapGetRandom() {
    HashTableMap<Integer, Integer> hashTable = new HashTableMap<Integer, Integer>();
    
    // check NPE for hashtable with no elements
    boolean wentInCatch = false;
    try {
      hashTable.getRandom();
    }
    catch (NullPointerException NPE) {
      wentInCatch = true;
    }
    assertEquals(wentInCatch, true);
    
    // check if a hashtable only has one element, it returns that element
    Pair<Integer, Integer> pair = new Pair<Integer, Integer>(1,2);
    hashTable.put(pair.getKey(), pair.getValue());

    Pair<Integer, Integer> randomPair = hashTable.getRandom();
    assertEquals(randomPair.getKey(), pair.getKey());
    assertEquals(randomPair.getValue(), pair.getValue());
  }
  
  @Test
  public void testHashTableMapToString() {
    // Test empty hashTable
    HashTableMap<String, String> hashTable = new HashTableMap<String, String>();
    assertEquals("", hashTable.toString());

    // Test hash table with elements
    hashTable.put("a", "easy");
    hashTable.put("b", "easy");
    String toString = "a - easy";
    toString += "\nb - easy";
    assertEquals(toString, hashTable.toString());
  }
  
  @Test
  public void testHangmanGameSetupPhrases() {
    HashTableMap<HangmanPhrase, Integer> hashTable = new HashTableMap<HangmanPhrase, Integer>();
    
    // See if blank document doesn't change the file
    File fileBlank = new File("testFileBlank.txt");
    HangmanGame.setupPhrases(hashTable, fileBlank);
    assertEquals("", hashTable.toString());

    // See if phrase added
    File filePhrase = new File("testFilePhrase.txt");
    HangmanGame.setupPhrases(hashTable, filePhrase);
    assertEquals("[phrase -> easy] - 4", hashTable.toString());
  }

  @Test
  public void testHangmanGameCheckCommand() {
    HashTableMap<String, String> hashTable = new HashTableMap<String, String>();
    
    // checking a command with empty hashtable
    String invalidCommandString = "This command does not exist.\n";
    invalidCommandString += ("Enter \"help\" (without the quotation marks) " +
      "if you need to learn the commands.");
    assertEquals(invalidCommandString, HangmanGame.checkCommand("a", hashTable));

    // checking an invalid command
    hashTable.put("a", "b");
    assertEquals(invalidCommandString, HangmanGame.checkCommand("c", hashTable));

    // checking a valid commabd
    assertEquals("b", HangmanGame.checkCommand("a", hashTable));
  }

  @Test
  public void testHangmsnGamePlayHelperMethods() {
    // Test livesCalculator method
    assertEquals(-1, HangmanGame.livesCalculator("a"));
    assertEquals(4, HangmanGame.livesCalculator("easy"));
    assertEquals(5, HangmanGame.livesCalculator("medium"));
    assertEquals(6, HangmanGame.livesCalculator("hard"));

    // Test inArrayList method
    ArrayList<String> arrList = new ArrayList<String>();
    assertEquals(false, HangmanGame.inArrayList("a", arrList));
    arrList.add("a");
    assertEquals(false, HangmanGame.inArrayList("b", arrList));
    assertEquals(true, HangmanGame.inArrayList("a", arrList));

    // Test removeLetter method
    assertEquals(false, HangmanGame.removeLetter("b", arrList));
    assertEquals(true, HangmanGame.removeLetter("a", arrList));
    assertEquals(false, HangmanGame.removeLetter("a", arrList));
  }
}
