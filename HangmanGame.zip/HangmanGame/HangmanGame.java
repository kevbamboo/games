// --== CS400 File Header Information ==--
// Name: Kevin Yiyang Song
// Email: kysong@wisc.edu
// Notes to Grader: Did not include definitions of params/methods that were very self-explanatory


import java.util.Scanner;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

/**
 * @author Kevin
 * 
 * Models the classic hangman game
 */
public class HangmanGame {
  /**
   * Starts the game
   * @param args
   */
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    // set up phrases and commands
    
    HashTableMap<HangmanPhrase, Integer> phrases = new HashTableMap<HangmanPhrase, Integer>();
    File file = new File("HangmanPhrases.txt");

    if (!setupPhrases(phrases, file)) {
      System.out.println("Phrases not set up correctly. Sorry for the inconvenience.");
      sc.close();
      return;
    }
    
    HashTableMap<String, String> commands = new HashTableMap<String, String>();
    setupCommands(commands);
    
    // display welcome message
    welcome();
    System.out.println("\n==================================================\n");

    boolean played = false;
    
    String inputCommand = sc.nextLine().trim().toLowerCase();
    while (!inputCommand.equals("quit")) {
      System.out.println();
      if (inputCommand.equals("play")) {
        // randomly choose a phrase
        Pair<HangmanPhrase, Integer> pair = getRandomPhrase(phrases);

        // start gameplay
        play(sc, pair.getKey(), pair.getValue());
        System.out.println("\n==================================================\n");

        played = true;
        
        System.out.println("Welcome back.");
      }
      else if (inputCommand.equals("add")) {
        addPhraseAndDifficulty(sc, phrases);
	System.out.println("\n==================================================\n");
      }
      else if (inputCommand.equals("print")) {
	System.out.println("[Phrase and difficulty] - Number of lives");
	System.out.println("--------------------------------------------------");
        System.out.println(phrases.toString());
	System.out.println("\n==================================================\n");
      }
      else {
        System.out.println(checkCommand(inputCommand, commands));
        System.out.println("\n==================================================\n");
      }
      
      inputCommand = sc.nextLine().trim().toLowerCase();
    }
    
    System.out.println();
    if (played) {
      System.out.println("Thanks for playing Hangman!");
    }
    System.out.println("Bye!");
    System.out.println("\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    
    sc.close();
  }
  
  /**
   * Sets up the commands
   */
  private static void setupCommands(HashTableMap<String, String> commands) {
    commands.put("help", helpCommandString());
    commands.put("how to", howToCommandString());
  }
  
  private static String helpCommandString() {
    return "The how to command explains how to play Hangman.\n" +
        "The play command starts a new game of random difficulty.\n" +
	"The add command allows you to add a phrase and difficulty you might be able to play with.\n" +
        "The quit command quits the game if playing, otherwise quits the running code.\n" +
        "The print command prints all of the phrases that are chosen from when playing.\n" +
        "Only the help and quit commands can be used during gameplay.";
  }
  
  private static String howToCommandString() {
    return "Each phrase has a different difficulty. You get 4 lives for easy, 5 for medium, and 6 for hard.\n" +
        "Input a single letter guess. If the letter is in the phrase, all instances where " +
        "the letter is will be shown. Otherwise, you will lose a life.\n" +
        "If you lose all your lives, then you lose. If you successfully guess all the letters " +
        "in the phrase without losing all your lives, then you win!";
  }
  
  /**
   * Sets up the phrases
   */
  public static boolean setupPhrases(HashTableMap<HangmanPhrase, Integer> phrases, File file) {
    try {
      BufferedReader reader = new BufferedReader(new FileReader(file));
      String phrase = reader.readLine();
      String difficulty = reader.readLine();
      
      // if no more phrases, stop adding
      while (phrase != null && difficulty != null) {
        phrases.put(new HangmanPhrase(phrase, difficulty), livesCalculator(difficulty));

	try {
	  phrase = reader.readLine();
	  difficulty = reader.readLine();
	}
	catch (Exception e) {
	  break;
	}
      }
      reader.close();
      return true;
    } catch (Exception e) {
      return false;
    }
  }
  
  /**
   * The welcome message
   */
  public static void welcome() {
    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
    System.out.println("Welcome to Hangman!");
    System.out.println("Enter \"help\" (without the quotation marks) " +
        "if you need to learn the commands.");
    System.out.println("Note that there are a limited number of phrases, so " +
	"you might get repeats if you play multiple times.");
    System.out.println("Have fun!");
  }
  
  /**
   * Check if the command exists, and return the output
   */
  public static String checkCommand(String inputCommand, HashTableMap<String, String> commands) {
    String ret  = "";
    if (!commands.containsKey(inputCommand)) {
      ret = "This command does not exist.\n";
      ret += "Enter \"help\" (without the quotation marks) " +
          "if you need to learn the commands.";
    }
    else {
      ret = commands.get(inputCommand);
    }
    
    return ret;
  }
  
  /**
   * Adds a user inputted phrase and difficulty
   */
  private static void addPhraseAndDifficulty(Scanner sc, HashTableMap<HangmanPhrase, Integer> phrases) {
    System.out.print("Enter the phrase (min 10 characters, max 40 characters): ");

    String phrase = sc.nextLine().trim().toLowerCase();
    while (phrase.length() < 10 || phrase.length() > 40) {
      if (phrase.length() < 10) {
       	System.out.println("Phrase is too short.");
      }
      else {
        System.out.println("Phrase is too long.");
      }
      System.out.print("Enter the phrase: ");
      phrase = sc.nextLine().trim().toLowerCase();
    }

    System.out.print("Enter the difficulty (easy, medium, or hard): ");

    String difficulty = sc.nextLine().trim().toLowerCase();
    while (!(difficulty.equals("easy") || difficulty.equals("medium") || difficulty.equals("hard"))) {
      System.out.println("Not a valid difficulty.");
      System.out.print("Enter the difficulty (easy, medium, or hard): ");
      difficulty = sc.nextLine().trim().toLowerCase();
    }

    phrases.put(new HangmanPhrase(phrase, difficulty), livesCalculator(difficulty));
  }
  
  /**
   * Return a random phrase for gameplay
   */
  public static Pair<HangmanPhrase, Integer> getRandomPhrase(HashTableMap<HangmanPhrase, Integer> phrases) {
    return phrases.getRandom();
  }
  
  public static boolean play(Scanner sc, HangmanPhrase hangmanPhrase, int lives) {
    // set up play
    
    
    HangedMan man = new HangedMan(lives);
    String phrase = hangmanPhrase.getPhrase();

    // What is shown to the player
    String guess = "";
    
    for (int i = 0; i < phrase.length(); i++) {
      char character = phrase.charAt(i);
      if (character < 97 || character > 122) {
        guess += character;
      } else {
        guess += "_";
      }
    }
    
    // records all unique letters in the phrase that HAVEN'T been inputted
    // thus by default all unique letters are added into the list
    ArrayList<String> lettersLeftInPhrase = new ArrayList<String>();
    lettersLeftInPhrase.add(phrase.substring(0, 1));
    for (int i = 1; i < phrase.length(); i++) {
      String letter = phrase.substring(i, i + 1);
      
      if (!letter.equals(" ") && !inArrayList(letter, lettersLeftInPhrase)) {
        lettersLeftInPhrase.add(letter);
      }
    }
    
    // records all letters that have been inputted so we know when there is a repeat
    ArrayList<String> usedLetters = new ArrayList<String>();
    
    
    // Start of the game
    
    System.out.println(hangmanPhrase.getDifficulty().toUpperCase() + " MODE - " + man.getLives() + " Lives");
    System.out.println("Enter 1 LOWERCASE letter to guess.\nHave Fun!!");

    while (!man.isDead() && !guess.equals(phrase)) {
      System.out.println(guess);
      System.out.print("Please enter a letter: ");
      String letter = sc.nextLine().toLowerCase();
      
      // check for available commands
      if (letter.equals("quit")) return false;
      if (letter.equals("help")) {
        System.out.println("\n" + helpCommandString() + "\n");
        continue;
      }
      if (letter.equals("how to") || letter.equals("add") || letter.equals("play") || letter.equals("print")) {
        System.out.println("Command not available during gameplay.\n");
	continue;
      }
      
      // check if it isn't a single letter
      if (letter.length() != 1 || !(letter.charAt(0) >= 97 && letter.charAt(0) <= 122)) {
        System.out.println("You did not enter a letter.\n");
        continue;
      }
      
      // check if the letter is in the phrase and hasn't been chosen
      if (inArrayList(letter, lettersLeftInPhrase)) {
        System.out.println("Nice, this letter is in the phrase!");
        
        // show the current guess with the chosen letter
        for (int i = 0; i < guess.length(); i++) {
          String character = guess.substring(i, i + 1);
          if (character.equals("_")) {
            if (letter.equals(phrase.substring(i, i + 1))) {
              if (i < guess.length() - 1) {
                guess = guess.substring(0, i) + letter + guess.substring(i + 1);
              } else {
                guess = guess.substring(0, i) + letter;
              }
            }
          }
        }
        // remove letter from letters left to not choose it again
        removeLetter(letter, lettersLeftInPhrase);
        // add letter to letters chosen to not choose it again
        usedLetters.add(letter);
      }
      // check if letter used already
      else if (inArrayList(letter, usedLetters)) {
        System.out.println("You have used this letter already!");
      }
      // otherwise not in phrase
      else {
        System.out.println("Sorry, this letter is not in the phrase. You lost a life!");
        usedLetters.add(letter);
        man.loseLife();
      }
      // show current hanged man
      man.hang();

      System.out.println("You have used the following letters:");

      for (int i = 0; i < usedLetters.size()-1; i++) {
        System.out.print(usedLetters.get(i) + " ");
      }
      System.out.println(usedLetters.get(usedLetters.size()-1));
      System.out.println();
      System.out.println("Lives left: " + man.getLives());
      System.out.println("\n--------------------------------------------------");
    }

    if (guess.equals(phrase)) {
      System.out.println("YOU WIN!!!!");
      return true;
    } else {
      System.out.println("You lost :(\nAnswer: " + phrase);
      return false;
    }
  }
  
  /**
   * Calculates lives for hangman based on difficulty
   */
  public static int livesCalculator(String difficulty) {
    difficulty = difficulty.trim().toLowerCase();

    if (difficulty.equals("easy")) {
      return 4;
    }
    else if (difficulty.equals("medium")) {
      return 5;
    }
    else if (difficulty.equals("hard")) {
      return 6;
    }

    return -1;
  }
  
  /**
   * Checks if the given letter is in the arraylist
   */
  public static boolean inArrayList(String letter, ArrayList<String> arrList) {
    boolean inList = false;
    for (int i = 0; i < arrList.size(); i++) {
      if (arrList.get(i).equals(letter)) {
        inList = true;
        return inList;
      }
    }
    return inList;
  }
  
  /**
   * Removes letter from arraylist
   * Returns is successful
   */
  public static boolean removeLetter(String letter, ArrayList<String> arrList) {
    for (int i = 0; i < arrList.size(); i++) {
      if (letter.equals(arrList.get(i))) {
        arrList.remove(i);
	return true;
      }
    }
    return false;
  }
}
