// --== CS400 File Header Information ==--
// Name: Kevin Yiyang Song
// Email: kysong@wisc.edu
// Notes to Grader: Did not include definitions of params/methods that were very self-explanatory


import java.util.LinkedList;
import java.util.NoSuchElementException;
import java.util.Random;

/**
 * This class models a HashTable with key and value pairs
 * 
 * @author Kevin
 *
 * @param <KeyType>
 * @param <ValueType>
 */
public class HashTableMap<KeyType, ValueType> implements MapADT<KeyType, ValueType> {
  private LinkedList<Pair<KeyType, ValueType>>[] hashTable;
  private int size;

  /**
   * Create a new HashTableMap with a capacity of the input capacity
   * 
   * @param capacity - original capacity of the hashTable HashTable
   */
  public HashTableMap(int capacity) {
    this.hashTable = (LinkedList<Pair<KeyType, ValueType>>[]) new LinkedList[capacity];
  }

  /**
   * Creates a new HashTableMap with a default capacity of 10
   */
  public HashTableMap() {
    this(10);
  }

  /**
   * Put a key-value pair into the HashTable, if possible
   * Check if it is necessary to grow the HashTable
   * 
   * @param key
   * @param value
   * @return successfully put or not
   */
  public boolean put(KeyType key, ValueType value) {
    // check for null
    if (key == null)
      return false;

    // check for non-distinct key
    int tableIndex = Math.abs(key.hashCode()) % hashTable.length;
    Pair<KeyType, ValueType> putPair = new Pair<KeyType, ValueType>(key, value);

    if (hashTable[tableIndex] == null) {
      hashTable[tableIndex] = new LinkedList<Pair<KeyType, ValueType>>();
    }

    for (Pair<KeyType, ValueType> comparePair : hashTable[tableIndex]) {
      if (putPair.getKey().equals(comparePair.getKey()))
        return false;
    }

    // put
    this.hashTable[tableIndex].add(putPair);
    this.size++;
    
    // check if need to grow
    if (isGrowingNecessary()) {
      growHashTable();
    }

    return true;
  }

  /**
   * Gets the value for the given key
   * 
   * @param key
   * @return value
   * @throws NoSuchElementException - for null key or key not found
   */
  public ValueType get(KeyType key) throws NoSuchElementException {
    // check for null
    if (key == null)
      throw new NoSuchElementException();

    // check for key in HashTable
    int tableIndex = Math.abs(key.hashCode()) % hashTable.length;
    
    if (hashTable[tableIndex] == null)
      throw new NoSuchElementException(); // key not found
    
    for (Pair<KeyType, ValueType> comparePair : hashTable[tableIndex]) {
      if (key.equals(comparePair.getKey()))
        return comparePair.getValue();
    }

    // key not found
    throw new NoSuchElementException();
  }
  
  /**
   * Returns a random pair
   * @return random key
   * @throws NullPointerException
   */
  public Pair<KeyType, ValueType> getRandom() throws NullPointerException {
    Random random = new Random();
    int[] indices = new int[hashTable.length];
    
    // if the hashtable has no values, throw NPE
    if (this.size == 0) {
      throw new NullPointerException();
    }
    
    // otherwise find all the indices with values
    int indicesSize = 0;
    for (int i = 0; i < hashTable.length; i++) {
      if (hashTable[i] != null) {
        indices[indicesSize] = i;
        indicesSize++;
        continue;
      }
    }
    
    // pick a random index with a value
    int arrIndex = indices[random.nextInt(indicesSize)];
    
    // pick a random index in the list
    int listIndex = random.nextInt(hashTable[arrIndex].size());
    
    int i = 0;
    Pair<KeyType, ValueType> pair = null;
    for (Pair<KeyType, ValueType> comparePair : hashTable[arrIndex]) {
      if (i == listIndex) {
        pair = comparePair;
        break;
      }
      i++;
    }
    return pair;
  }

  /**
   * Check if the HashTable contains the given key
   * 
   * @param key
   * @return contains key or not
   */
  public boolean containsKey(KeyType key) {
    // check for null
    if (key == null)
      return false;

    // check for key in HashTable
    int tableIndex = Math.abs(key.hashCode()) % hashTable.length;
    
    if (hashTable[tableIndex] == null) return false;
    
    for (Pair<KeyType, ValueType> comparePair : hashTable[tableIndex]) {
      if (key.equals(comparePair.getKey()))
        return true;
    }

    return false;
  }

  /**
   * Remove the Pair with the given key, then return the value
   * 
   * @param key
   * @return value removed
   */
  public ValueType remove(KeyType key) {
    // check for null
    if (key == null)
      return null;

    int tableIndex = Math.abs(key.hashCode()) % hashTable.length;

    int listRetIndex = 0;
    for (Pair<KeyType, ValueType> comparePair : hashTable[tableIndex]) {
      if (key.equals(comparePair.getKey())) {
        this.size--;
        this.hashTable[tableIndex].remove(listRetIndex);
      }
      listRetIndex++;
    }

    return null;
  }

  public void clear() {
    this.hashTable = (LinkedList<Pair<KeyType, ValueType>>[]) new LinkedList[this.size];
    this.size = 0;
  }

  public int size() {
    return this.size;
  }

  private boolean isGrowingNecessary() {
    return getLoadCapacity() >= 0.85;
  }

  private double getLoadCapacity() {
    return size() * 1.0 / this.hashTable.length;
  }

  /**
   * Hold a reference of the current HashTable
   * Set the current HashTable to a new, blank HashTable with double the length
   * Copy over the Pairs using put()
   */
  private void growHashTable() {
    LinkedList<Pair<KeyType, ValueType>>[] oldHashTable = this.hashTable;
    this.hashTable =
        (LinkedList<Pair<KeyType, ValueType>>[]) new LinkedList[this.hashTable.length * 2];
    
    this.size = 0; // because put increases the size but we want the size before and after to be
                   // the same
    
    for (int i = 0; i < oldHashTable.length; i++) {
      if (oldHashTable[i] != null) {
        for (Pair<KeyType, ValueType> comparePair : oldHashTable[i]) {
          put(comparePair.getKey(), comparePair.getValue());
        }
      }
    }

  }
  
  /**
   * Returns the string version of this HashTableMap
   */
  public String toString() {
    String toString = "";
    // do some formatting
    for (LinkedList<Pair<KeyType, ValueType>> list : hashTable) {
      if (list != null) {
        Object[] arr = list.toArray();
        
        for (int i = 0; i < arr.length; i++) {
          toString += arr[i].toString() + "\n";
        }
      }
    }
    
    return toString.trim();
  }
}
